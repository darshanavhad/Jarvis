@echo off
title JARVIS -- Wake Word Service
color 0A

echo ==============================================
echo   JARVIS -- Starting Wake Word Listener...
echo ==============================================

cd /d "%~dp0"

REM ── Check if setup has been completed ──────────────────────────────
if not exist ".jarvis_setup_complete" (
    echo First-time launch detected. Running setup first...
    echo.
    python J.A.R.V.I.S_SETUP.py
    if %ERRORLEVEL% NEQ 0 (
        echo Setup failed. Check the messages above.
        pause
        exit /b %ERRORLEVEL%
    )
)

echo.
echo Launching Wake Word Listener ("wake up jarvis")...
python wake_service.py

echo.
pause
