def two_sum(nums, target):
    """
    Solves the two sum problem.
    """
    hashmap = {}
    for i, num in enumerate(nums):
        complement = target - num
        if complement in hashmap:
            return [hashmap[complement], i]
        hashmap[num] = i
    return []

# Example usage
nums = [2, 7, 11, 15]
target = 9
result = two_sum(nums, target)
print(f"Input: nums={nums}, target={target}")
print(f"Output: {result}")

nums2 = [3, 2, 4]
target2 = 6
result2 = two_sum(nums2, target2)
print(f"Input: nums={nums2}, target={target2}")
print(f"Output: {result2}")