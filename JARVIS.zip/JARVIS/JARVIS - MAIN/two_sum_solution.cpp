#include <vector>
#include <unordered_map>
#include <iostream>

std::vector<int> twoSum(std::vector<int>& nums, int target) {
    std::unordered_map<int, int> hashmap;
    for (int i = 0; i < nums.size(); ++i) {
        int complement = target - nums[i];
        if (hashmap.count(complement)) {
            return {hashmap[complement], i};
        }
        hashmap[nums[i]] = i;
    }
    return {};
}

int main() {
    std::vector<int> nums = {2, 7, 11, 15};
    int target = 9;
    std::vector<int> result = twoSum(nums, target);
    std::cout << "Input: nums=[2, 7, 11, 15], target=9" << std::endl;
    std::cout << "Output: [" << result[0] << ", " << result[1] << "]" << std::endl;

    std::vector<int> nums2 = {3, 2, 4};
    int target2 = 6;
    std::vector<int> result2 = twoSum(nums2, target2);
    std::cout << "Input: nums=[3, 2, 4], target=6" << std::endl;
    std::cout << "Output: [" << result2[0] << ", " << result2[1] << "]" << std::endl;

    return 0;
}