"""
vscode_writer.py — J.A.R.V.I.S VS Code Writer
Opens VS Code, creates a new file with generated code, and opens it for editing.
"""
from utils.env import get_api_key, get_base_dir
import subprocess
import sys
import os
import re
import time
import platform
from pathlib import Path

BASE_DIR = get_base_dir()
DESKTOP  = Path.home() / "Desktop"


_WIN_HIDE = {}
if platform.system() == "Windows":
    _WIN_HIDE = {"creationflags": subprocess.CREATE_NO_WINDOW}


EXT_MAP = {
    "python": ".py", "py": ".py",
    "javascript": ".js", "js": ".js",
    "typescript": ".ts", "ts": ".ts",
    "html": ".html", "css": ".css",
    "java": ".java", "cpp": ".cpp", "c": ".c",
    "bash": ".sh", "shell": ".sh", "powershell": ".ps1",
    "sql": ".sql", "json": ".json", "rust": ".rs", "go": ".go",
    "csharp": ".cs", "cs": ".cs", "ruby": ".rb", "php": ".php",
    "kotlin": ".kt", "swift": ".swift", "r": ".r", "dart": ".dart",
}


def _get_gemini():
    from google import genai
    client = genai.Client(api_key=get_api_key("gemini_api_key"))

    class _W:
        def generate_content(self, contents):
            return client.models.generate_content(model="gemini-2.5-flash", contents=contents)

    return _W()


def _clean_code(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```[a-zA-Z]*\n?", "", text)
    text = re.sub(r"\n?```$", "", text)
    return text.strip()


def _find_vscode() -> str | None:
    """Find VS Code executable on the system."""
    if platform.system() == "Windows":
        candidates = [
            r"C:\Program Files\Microsoft VS Code\Code.exe",
            r"C:\Program Files (x86)\Microsoft VS Code\Code.exe",
            os.path.expanduser(r"~\AppData\Local\Programs\Microsoft VS Code\Code.exe"),
        ]
        for c in candidates:
            if os.path.isfile(c):
                return c
        # Try from PATH
        try:
            result = subprocess.run(["where", "code"], capture_output=True, text=True, **_WIN_HIDE)
            if result.returncode == 0:
                lines = result.stdout.strip().splitlines()
                if lines:
                    return lines[0]
        except Exception:
            pass
    elif platform.system() == "Darwin":
        candidates = [
            "/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code",
            "/usr/local/bin/code",
        ]
        for c in candidates:
            if os.path.isfile(c):
                return c
    else:
        try:
            result = subprocess.run(["which", "code"], capture_output=True, text=True)
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
    return None


def _generate_code(description: str, language: str) -> str:
    """Use Gemini to generate code for the given description."""
    gemini = _get_gemini()
    prompt = (
        f"Write complete, working {language} code that does the following:\n"
        f"{description}\n\n"
        "Requirements:\n"
        "- Write clean, well-commented, production-ready code\n"
        "- Include all necessary imports\n"
        "- Add helpful inline comments\n"
        "- Return ONLY the raw code, no markdown fences, no explanation\n"
        "- Make it fully functional and runnable\n"
    )
    try:
        resp = gemini.generate_content(prompt)
        return _clean_code(resp.text)
    except Exception as e:
        print(f"[VSCode Writer] Code generation failed: {e}")
        return f"# Code generation failed: {e}\n# Description: {description}"


def _open_in_vscode(file_path: str) -> bool:
    """Open a file in VS Code."""
    vscode = _find_vscode()

    try:
        if platform.system() == "Windows":
            if vscode and os.path.isfile(vscode):
                subprocess.Popen(
                    [vscode, file_path],
                    creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                )
            else:
                # Try 'code' from PATH via shell
                subprocess.Popen(
                    f'code "{file_path}"',
                    shell=True,
                    creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                )
        else:
            executable = vscode or "code"
            subprocess.Popen([executable, file_path])
        return True
    except Exception as e:
        print(f"[VSCode Writer] Failed to open VS Code: {e}")
        return False


def vscode_writer(parameters: dict = None, player=None, speak=None) -> str:
    """
    Main handler: generates code with Gemini and opens it in VS Code.
    
    Parameters:
        description (str): What the code should do
        language (str): Programming language (default: python)
        filename (str): Optional filename/path to save
    """
    params      = parameters or {}
    description = params.get("description", "").strip()
    language    = params.get("language", "python").strip().lower()
    filename    = params.get("filename", "").strip()

    if not description:
        return "No description provided. Tell me what code you want written."

    # Resolve extension
    ext = EXT_MAP.get(language, ".py")

    # Determine save path
    if filename:
        p = Path(filename)
        if not p.is_absolute():
            save_path = DESKTOP / p
        else:
            save_path = p
        # Add extension if missing
        if not save_path.suffix:
            save_path = save_path.with_suffix(ext)
    else:
        safe_name = re.sub(r"[^a-z0-9_]", "_", description[:30].lower()).strip("_")
        safe_name = safe_name or "jarvis_code"
        save_path = DESKTOP / f"{safe_name}{ext}"

    if player:
        player.write_log(f"[VSCode] Generating {language} code: {description[:60]}...")

    if speak:
        speak(f"Generating your {language} code now, sir. One moment.")

    # Generate code
    code = _generate_code(description, language)

    # Save the file
    try:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        save_path.write_text(code, encoding="utf-8")
        print(f"[VSCode Writer] Saved: {save_path}")
    except Exception as e:
        return f"Failed to save file: {e}"

    if player:
        player.write_log(f"[VSCode] Saved to {save_path}")

    # Open in VS Code
    opened = _open_in_vscode(str(save_path))

    if opened:
        if player:
            player.write_log(f"[VSCode] Opened in VS Code: {save_path.name}")
        lines = len(code.splitlines())
        return (
            f"Done! I've written {lines} lines of {language} code and opened it in VS Code. "
            f"File saved at: {save_path}"
        )
    else:
        return (
            f"Code written ({len(code.splitlines())} lines) and saved to {save_path}, "
            f"but VS Code was not found. Please install VS Code or open the file manually."
        )
